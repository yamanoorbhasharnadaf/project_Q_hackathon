import os
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator

class QuantumRandomKeyGenerator:
    """Generates true quantum random entropy using Hadamard superposition gates in Qiskit."""
    def __init__(self):
        # Local Qiskit simulator for quantum circuit execution
        self.simulator = AerSimulator()

    def generate_quantum_byte(self) -> int:
        """Generates 8 bits of quantum entropy using 8 qubits in superposition."""
        # Create a circuit with 8 qubits and 8 classical bits
        qc = QuantumCircuit(8, 8)
        # Put each qubit into an equal superposition state (|0> + |1>) / sqrt(2)
        for qubit in range(8):
            qc.h(qubit)
        # Measure all 8 qubits
        qc.measure(range(8), range(8))
        
        # Run circuit on quantum simulator
        job = self.simulator.run(qc, shots=1)
        result = job.result()
        counts = result.get_counts(qc)
        
        # Get the 8-bit measured bitstring (e.g., '10110101')
        bitstring = list(counts.keys())[0]
        # Convert bitstring to an integer byte (0-255)
        return int(bitstring, 2)

    def generate_256bit_key(self) -> bytes:
        """Generates a 32-byte (256-bit) cryptographic key purely from quantum entropy."""
        key_bytes = bytearray()
        for _ in range(32):
            key_bytes.append(self.generate_quantum_byte())
        return bytes(key_bytes)


class QuantumSafeVault:
    """Encrypts and decrypts payloads using AES-256-GCM authenticated encryption."""
    def __init__(self, key: bytes):
        self.key = key
        self.aesgcm = AESGCM(self.key)

    def encrypt_data(self, plaintext: str) -> dict:
        """Encrypts plaintext using the quantum-generated key."""
        # Generate a unique 96-bit (12-byte) initialization vector (nonce)
        nonce = os.urandom(12)
        plaintext_bytes = plaintext.encode("utf-8")

        ciphertext = self.aesgcm.encrypt(nonce, plaintext_bytes, associated_data=None)
        return {
            "nonce": nonce.hex(),
            "ciphertext": ciphertext.hex(),
        }

    def decrypt_data(self, encrypted_payload: dict) -> str:
        """Decrypts ciphertext using the stored quantum key and nonce."""
        nonce = bytes.fromhex(encrypted_payload["nonce"])
        ciphertext = bytes.fromhex(encrypted_payload["ciphertext"])

        decrypted_bytes = self.aesgcm.decrypt(nonce, ciphertext, associated_data=None)
        return decrypted_bytes.decode("utf-8")