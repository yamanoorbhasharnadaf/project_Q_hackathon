import streamlit as st
from vault import QuantumRandomKeyGenerator, QuantumSafeVault

st.set_page_config(
    page_title="Quantum-Safe Vault",
    page_icon="🛡️",
    layout="wide"
)

st.title("🛡️ Quantum-Safe Vault")
st.caption("Powered by Qiskit Quantum Random Number Generation & AES-256-GCM")

# Initialize Session States
if "quantum_key" not in st.session_state:
    st.session_state.quantum_key = None
if "encrypted_payload" not in st.session_state:
    st.session_state.encrypted_payload = None

# Sidebar - Key Generation
st.sidebar.header("🔑 Quantum Key Management")
if st.sidebar.button("Generate 256-bit Quantum Key", type="primary"):
    with st.spinner("Simulating Hadamard Superposition Circuit..."):
        qrng = QuantumRandomKeyGenerator()
        st.session_state.quantum_key = qrng.generate_256bit_key()
        st.session_state.encrypted_payload = None
        st.sidebar.success("Quantum Key Generated!")

if st.session_state.quantum_key:
    st.sidebar.subheader("Active Key (Hex)")
    st.sidebar.code(st.session_state.quantum_key.hex(), language="text")
else:
    st.sidebar.info("Generate a Quantum Key to begin encryption.")

# Main Interface Tabs
tab1, tab2 = st.tabs(["🔐 Encrypt Data", "🔓 Decrypt Data"])

# TAB 1: ENCRYPTION
with tab1:
    st.header("Encrypt Plaintext Secret")
    user_input = st.text_area("Enter secret message or confidential data:", height=120)
    
    if st.button("Encrypt Secret"):
        if not st.session_state.quantum_key:
            st.error("Please generate a Quantum Key in the sidebar first!")
        elif not user_input.strip():
            st.warning("Please enter some text to encrypt.")
        else:
            vault = QuantumSafeVault(st.session_state.quantum_key)
            payload = vault.encrypt_data(user_input)
            st.session_state.encrypted_payload = payload
            st.success("Data successfully encrypted with Post-Quantum Security!")

    if st.session_state.encrypted_payload:
        st.subheader("Encrypted Payload Output")
        st.json(st.session_state.encrypted_payload)

# TAB 2: DECRYPTION
with tab2:
    st.header("Decrypt Encrypted Payload")
    if not st.session_state.encrypted_payload:
        st.info("No payload encrypted yet. Encrypt a message in the first tab to view decryption here.")
    else:
        st.subheader("Current Encrypted Payload")
        st.json(st.session_state.encrypted_payload)
        
        if st.button("Decrypt Secret"):
            if not st.session_state.quantum_key:
                st.error("Quantum Key missing. Regenerate or preserve key.")
            else:
                try:
                    vault = QuantumSafeVault(st.session_state.quantum_key)
                    decrypted_text = vault.decrypt_data(st.session_state.encrypted_payload)
                    st.success("Decryption Successful!")
                    st.text_area("Decrypted Plaintext:", value=decrypted_text, height=120, disabled=True)
                except Exception as e:
                    st.error(f"Decryption failed: {str(e)}")