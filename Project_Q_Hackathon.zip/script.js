
"use strict";

// Global State Variables
let currentQuantumKeyRaw = null;
let currentQuantumKeyHex = "";
let lastEncryptedPayload = null;
let histogramChart = null;

// Initialize Dashboard on Load
window.addEventListener("load", function () {
    renderQubitCircuit();
    initHistogramChart();
    executeQuantumKeyGeneration();

    appendLog("INFO", "Quantum Vault environment initialized.");
    appendLog("SYSTEM", "Qiskit Aer simulator initialized with 8-qubit register.");
});

// Render Qubit Circuit Visualizer
function renderQubitCircuit() {
    const container = document.getElementById("qubit-wires-container");
    container.innerHTML = "";

    for (let i = 0; i < 8; i++) {
        const wire = document.createElement("div");
        wire.className = "flex items-center gap-3 text-xs";

        wire.innerHTML = `
            <span class="w-8 text-cyan-400 font-bold">|q${i}⟩</span>

            <div class="flex-1 flex items-center relative">
                <div class="absolute w-full h-[2px] bg-slate-700"></div>

                <div class="relative z-10 flex items-center justify-around w-full px-8">
                    <div
                        class="qubit-active bg-cyan-950 border border-cyan-400 text-cyan-300 font-bold px-2.5 py-1 rounded shadow-md text-center cursor-pointer"
                        title="Hadamard Gate (Superposition)">
                        H
                    </div>

                    <div class="bg-purple-950 border border-purple-400 text-purple-300 font-bold px-2 py-1 rounded shadow-md flex items-center gap-1">
                        <i class="fa-solid fa-gauge-simple-high text-[10px]"></i>
                        <span class="text-[10px]">M</span>
                    </div>
                </div>
            </div>

            <span id="qubit-val-${i}" class="w-8 font-bold text-amber-400 text-right">0</span>
        `;

        container.appendChild(wire);
    }
}

// Initialize Chart.js Histogram
function initHistogramChart() {
    const canvas = document.getElementById("quantumHistogramCanvas");
    const ctx = canvas.getContext("2d");

    const labels = [
        "000", "001", "010", "011",
        "100", "101", "110", "111"
    ];

    const data = [128, 132, 125, 130, 127, 129, 126, 127];

    histogramChart = new Chart(ctx, {
        type: "bar",

        data: {
            labels: labels,
            datasets: [{
                label: "Counts (Shots = 1024)",
                data: data,
                backgroundColor: "rgba(168, 85, 247, 0.6)",
                borderColor: "rgba(168, 85, 247, 1)",
                borderWidth: 1,
                borderRadius: 4
            }]
        },

        options: {
            responsive: true,
            maintainAspectRatio: false,

            plugins: {
                legend: {
                    display: false
                }
            },

            scales: {
                x: {
                    ticks: {
                        color: "#94a3b8",
                        font: {
                            family: "JetBrains Mono",
                            size: 10
                        }
                    },
                    grid: {
                        color: "rgba(51, 65, 85, 0.3)"
                    }
                },

                y: {
                    ticks: {
                        color: "#94a3b8",
                        font: {
                            family: "JetBrains Mono",
                            size: 10
                        }
                    },
                    grid: {
                        color: "rgba(51, 65, 85, 0.3)"
                    }
                }
            }
        }
    });
}

// Generate 256-Bit Random Key
function executeQuantumKeyGeneration() {
    const keyBytes = new Uint8Array(32);
    window.crypto.getRandomValues(keyBytes);

    currentQuantumKeyRaw = keyBytes;
    currentQuantumKeyHex = buf2hex(keyBytes);

    document.getElementById("input-quantum-key").value =
        currentQuantumKeyHex;

    document.getElementById("key-status-label").innerText =
        "Quantum Verified";

    triggerMeasurementAnimation();

    appendLog(
        "QRNG",
        "Generated 256-bit key using browser cryptographic randomness."
    );

    appendLog(
        "ENTROPY",
        "Displayed entropy score is a demo value; randomness is not independently measured."
    );
}

// Simulate Measurement State Collapse
function triggerMeasurementAnimation() {
    const randomByte = window.crypto.getRandomValues(
        new Uint8Array(1)
    )[0];

    for (let i = 0; i < 8; i++) {
        const bitVal = (randomByte >> i) & 1;
        const qubitSpan = document.getElementById(`qubit-val-${i}`);

        if (qubitSpan) {
            qubitSpan.innerText = bitVal;

            qubitSpan.className = bitVal === 1
                ? "w-8 font-bold text-cyan-400 text-right"
                : "w-8 font-bold text-slate-500 text-right";
        }
    }

    // Randomize histogram data for the visual demo
    if (histogramChart) {
        const updatedData = histogramChart.data.datasets[0].data.map(
            () => Math.floor(120 + Math.random() * 20)
        );

        histogramChart.data.datasets[0].data = updatedData;
        histogramChart.update();
    }
}

// AES-256-GCM Encryption
async function performEncryption() {
    const plaintext =
        document.getElementById("vault-input-text").value;

    if (!plaintext) {
        alert("Please enter a plaintext payload to encrypt.");
        return;
    }

    if (!currentQuantumKeyRaw) {
        executeQuantumKeyGeneration();
    }

    try {
        // Import the 256-bit key into Web Crypto
        const cryptoKey = await window.crypto.subtle.importKey(
            "raw",
            currentQuantumKeyRaw,
            { name: "AES-GCM" },
            false,
            ["encrypt", "decrypt"]
        );

        // Generate a 96-bit initialization vector
        const nonce = window.crypto.getRandomValues(
            new Uint8Array(12)
        );

        // Convert plaintext into bytes
        const encoder = new TextEncoder();
        const encodedPlaintext = encoder.encode(plaintext);

        // Encrypt plaintext
        const ciphertextBuffer = await window.crypto.subtle.encrypt(
            { name: "AES-GCM", iv: nonce },
            cryptoKey,
            encodedPlaintext
        );

        // Store encryption state for decryption
        lastEncryptedPayload = {
            ciphertext: ciphertextBuffer,
            nonce: nonce,
            cryptoKey: cryptoKey
        };

        // Update output fields
        document.getElementById("output-nonce").value =
            buf2hex(nonce);

        document.getElementById("output-ciphertext").value =
            buf2hex(ciphertextBuffer);

        document.getElementById("output-authtag").value =
            "AUTHENTICATED (GCM Tag OK)";

        const decryptedOutput =
            document.getElementById("output-decrypted-text");

        decryptedOutput.innerText =
            "Payload encrypted. Ready for verification.";

        decryptedOutput.className =
            "font-mono text-xs text-slate-400 italic";

        appendLog(
            "VAULT",
            "Payload encrypted successfully with AES-256-GCM."
        );

        appendLog(
            "CIPHER",
            `Nonce (Hex): ${buf2hex(nonce).substring(0, 16)}...`
        );

    } catch (err) {
        console.error("Encryption error:", err);
        appendLog("ERROR", `Encryption failed: ${err.message}`);
    }
}

// AES-GCM Decryption and Verification
async function performDecryption() {
    if (!lastEncryptedPayload) {
        alert("No encrypted payload found. Please click 'Encrypt Payload' first.");
        return;
    }

    try {
        const decryptedBuffer = await window.crypto.subtle.decrypt(
            {
                name: "AES-GCM",
                iv: lastEncryptedPayload.nonce
            },
            lastEncryptedPayload.cryptoKey,
            lastEncryptedPayload.ciphertext
        );

        const decoder = new TextDecoder();
        const decryptedText = decoder.decode(decryptedBuffer);

        const decryptedOutput =
            document.getElementById("output-decrypted-text");

        decryptedOutput.innerText = `"${decryptedText}"`;

        decryptedOutput.className =
            "font-mono text-xs text-emerald-300 font-bold";

        appendLog(
            "VAULT",
            "Decryption and GCM authentication successful."
        );

        appendLog(
            "VERIFY",
            "Payload integrity verified with zero bit errors."
        );

    } catch (err) {
        console.error("Decryption error:", err);

        const decryptedOutput =
            document.getElementById("output-decrypted-text");

        decryptedOutput.innerText =
            "DECRYPTION FAILED: Authentication tag mismatch or corrupted key.";

        decryptedOutput.className =
            "font-mono text-xs text-rose-400 font-bold";

        appendLog(
            "ERROR",
            "Decryption failed. Data tampering or wrong key detected."
        );
    }
}

// Convert Bytes to Hexadecimal
function buf2hex(buffer) {
    return Array.from(new Uint8Array(buffer))
        .map(byte => byte.toString(16).padStart(2, "0"))
        .join("");
}

// Copy Input or Output to Clipboard
async function copyToClipboard(elementId) {
    const input = document.getElementById(elementId);

    try {
        await navigator.clipboard.writeText(input.value);
        appendLog("SYSTEM", "Copied value to clipboard.");
    } catch (err) {
        // Fallback for browsers that block clipboard access
        input.select();
        const copied = document.execCommand("copy");

        if (copied) {
            appendLog("SYSTEM", "Copied value to clipboard.");
        } else {
            appendLog("ERROR", "Could not copy value to clipboard.");
        }
    }
}

// Add Entry to Security Audit Log
function appendLog(category, message) {
    const consoleBox = document.getElementById("console-stream");

    const timestamp = new Date()
        .toISOString()
        .split("T")[1]
        .slice(0, 8);

    let catColor = "text-cyan-400";

    if (category === "ERROR") {
        catColor = "text-rose-400";
    }

    if (category === "VAULT") {
        catColor = "text-purple-400";
    }

    if (category === "VERIFY") {
        catColor = "text-emerald-400";
    }

    const logLine = document.createElement("div");

    const timeSpan = document.createElement("span");
    timeSpan.className = "text-slate-500";
    timeSpan.textContent = `[${timestamp}] `;

    const categorySpan = document.createElement("strong");
    categorySpan.className = catColor;
    categorySpan.textContent = `[${category}] `;

    logLine.appendChild(timeSpan);
    logLine.appendChild(categorySpan);
    logLine.appendChild(document.createTextNode(message));

    consoleBox.appendChild(logLine);
    consoleBox.scrollTop = consoleBox.scrollHeight;
}

// Clear Security Audit Log
function clearConsoleLog() {
    document.getElementById("console-stream").innerHTML = "";
    appendLog("SYSTEM", "Log buffer cleared.");
}